import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")
    const role = searchParams.get("role")

    if (!userId || !role) {
      return NextResponse.json({ error: "User ID and role are required" }, { status: 400 })
    }

    // In a real app, you would fetch from database
    // For demo purposes, return mock data based on role

    if (role === "student") {
      const studentProfile = {
        id: userId,
        firstName: "John",
        lastName: "Doe",
        email: "john.doe@university.edu",
        institution: "Tech University",
        nfcId: "NFC001",
        gpa: 3.85,
        attendance: 94,
        credits: { current: 18, total: 20 },
        courses: [
          { name: "Advanced Algorithms", code: "CS 401", grade: "A-", progress: 75 },
          { name: "Database Systems", code: "CS 350", grade: "B+", progress: 60 },
          { name: "Software Engineering", code: "CS 320", grade: "A", progress: 85 },
          { name: "Machine Learning", code: "CS 480", grade: "B", progress: 45 },
        ],
        recentActivity: [
          { action: "Assignment submitted", course: "CS 401", time: "2 hours ago" },
          { action: "Attended lecture", course: "CS 350", time: "1 day ago" },
          { action: "Quiz completed", course: "CS 320", time: "2 days ago" },
        ],
      }
      return NextResponse.json(studentProfile)
    } else if (role === "teacher") {
      const teacherProfile = {
        id: userId,
        firstName: "Robert",
        lastName: "Wilson",
        email: "prof.wilson@university.edu",
        institution: "Tech University",
        department: "Computer Science",
        totalStudents: 156,
        activeCourses: 4,
        avgAttendance: 87,
        avgGrade: "B+",
        courses: [
          { name: "Advanced Algorithms", code: "CS 401", students: 45, attendance: 92 },
          { name: "Database Systems", code: "CS 350", students: 38, attendance: 85 },
          { name: "Software Engineering", code: "CS 320", students: 42, attendance: 88 },
          { name: "Machine Learning", code: "CS 480", students: 31, attendance: 90 },
        ],
        todayStats: {
          classesToday: 3,
          assignmentsDue: 7,
          pendingGrades: 12,
          absentStudents: 5,
        },
      }
      return NextResponse.json(teacherProfile)
    }

    return NextResponse.json({ error: "Invalid role" }, { status: 400 })
  } catch (error) {
    console.error("Profile fetch error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
