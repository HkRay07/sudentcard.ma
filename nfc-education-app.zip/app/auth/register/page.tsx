"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { GraduationCap, Users, ArrowRight, ArrowLeft, Mail, Lock, User, School } from "lucide-react"
import Link from "next/link"

type UserRole = "student" | "teacher" | null

export default function RegisterPage() {
  const [step, setStep] = useState(1)
  const [selectedRole, setSelectedRole] = useState<UserRole>(null)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    firstName: "",
    lastName: "",
    institution: "",
    massarCode: "", // Add this line
  })

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role)
    setStep(2)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const validateMassarCode = (code: string) => {
    const massarRegex = /^[A-Za-z]\d{9}$/
    return massarRegex.test(code)
  }

  const validatePassword = (password: string) => {
    const minLength = 8
    const hasUpperCase = /[A-Z]/.test(password)
    const hasLowerCase = /[a-z]/.test(password)
    const hasNumbers = /\d/.test(password)
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password)

    return {
      isValid: password.length >= minLength && hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChar,
      minLength: password.length >= minLength,
      hasUpperCase,
      hasLowerCase,
      hasNumbers,
      hasSpecialChar,
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically handle the registration logic
    console.log("Registration data:", { ...formData, role: selectedRole })
    // Redirect to dashboard based on role
    if (selectedRole === "student") {
      window.location.href = "/dashboard/student"
    } else {
      window.location.href = "/dashboard/teacher"
    }
  }

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center space-x-2 mb-6">
            <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">EduNFC</span>
          </Link>
          <h1 className="text-3xl font-bold mb-2">Create Your Account</h1>
          <p className="text-gray-400">Join the future of education</p>
        </div>

        {/* Step 1: Role Selection */}
        {step === 1 && (
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-center text-white">Choose Your Role</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                onClick={() => handleRoleSelect("student")}
                className="w-full h-20 bg-gray-800 hover:bg-orange-500/20 border border-gray-600 hover:border-orange-500 text-left flex items-center space-x-4 transition-all duration-300"
                variant="outline"
              >
                <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <GraduationCap className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <div className="font-semibold text-white">Student</div>
                  <div className="text-sm text-gray-400">Access your grades, attendance, and profile</div>
                </div>
                <ArrowRight className="w-5 h-5 text-gray-400 ml-auto" />
              </Button>

              <Button
                onClick={() => handleRoleSelect("teacher")}
                className="w-full h-20 bg-gray-800 hover:bg-orange-500/20 border border-gray-600 hover:border-orange-500 text-left flex items-center space-x-4 transition-all duration-300"
                variant="outline"
              >
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-green-400" />
                </div>
                <div>
                  <div className="font-semibold text-white">Teacher</div>
                  <div className="text-sm text-gray-400">Manage students, grades, and analytics</div>
                </div>
                <ArrowRight className="w-5 h-5 text-gray-400 ml-auto" />
              </Button>

              <div className="text-center pt-4">
                <p className="text-sm text-gray-400">
                  Already have an account?{" "}
                  <Link href="/auth/login" className="text-orange-400 hover:text-orange-300">
                    Sign in
                  </Link>
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Registration Form */}
        {step === 2 && (
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <div className="flex items-center space-x-2 mb-2">
                <Button
                  onClick={() => setStep(1)}
                  variant="ghost"
                  size="sm"
                  className="text-gray-400 hover:text-white p-0"
                >
                  <ArrowLeft className="w-4 h-4" />
                </Button>
                <Badge
                  className={`${selectedRole === "student" ? "bg-blue-500/20 text-blue-400" : "bg-green-500/20 text-green-400"}`}
                >
                  {selectedRole === "student" ? "🎓 Student" : "👨‍🏫 Teacher"} Registration
                </Badge>
              </div>
              <CardTitle className="text-white">Complete Your Profile</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName" className="text-gray-300">
                      First Name
                    </Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                      <Input
                        id="firstName"
                        name="firstName"
                        type="text"
                        required
                        className="pl-10 bg-gray-800 border-gray-600 text-white"
                        value={formData.firstName}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="lastName" className="text-gray-300">
                      Last Name
                    </Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                      <Input
                        id="lastName"
                        name="lastName"
                        type="text"
                        required
                        className="pl-10 bg-gray-800 border-gray-600 text-white"
                        value={formData.lastName}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="email" className="text-gray-300">
                    Email
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      required
                      className="pl-10 bg-gray-800 border-gray-600 text-white"
                      value={formData.email}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="institution" className="text-gray-300">
                    Institution
                  </Label>
                  <div className="relative">
                    <School className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      id="institution"
                      name="institution"
                      type="text"
                      required
                      className="pl-10 bg-gray-800 border-gray-600 text-white"
                      value={formData.institution}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="massarCode" className="text-gray-300">
                    Massar Code
                  </Label>
                  <div className="relative">
                    <School className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      id="massarCode"
                      name="massarCode"
                      type="text"
                      required
                      placeholder="e.g., A123456789"
                      className={`pl-10 bg-gray-800 border-gray-600 text-white ${
                        formData.massarCode && !validateMassarCode(formData.massarCode) ? "border-red-500" : ""
                      }`}
                      value={formData.massarCode}
                      onChange={handleInputChange}
                    />
                  </div>
                  {formData.massarCode && !validateMassarCode(formData.massarCode) && (
                    <p className="text-red-400 text-xs mt-1">Massar code must be 1 letter followed by 9 numbers</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="password" className="text-gray-300">
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      id="password"
                      name="password"
                      type="password"
                      required
                      className="pl-10 bg-gray-800 border-gray-600 text-white"
                      value={formData.password}
                      onChange={handleInputChange}
                    />
                  </div>
                  {formData.password && (
                    <div className="mt-2 space-y-1">
                      <div className="text-xs text-gray-400">Password strength:</div>
                      <div className="space-y-1">
                        {(() => {
                          const validation = validatePassword(formData.password)
                          return (
                            <>
                              <div className={`text-xs ${validation.minLength ? "text-green-400" : "text-red-400"}`}>
                                ✓ At least 8 characters
                              </div>
                              <div className={`text-xs ${validation.hasUpperCase ? "text-green-400" : "text-red-400"}`}>
                                ✓ One uppercase letter
                              </div>
                              <div className={`text-xs ${validation.hasLowerCase ? "text-green-400" : "text-red-400"}`}>
                                ✓ One lowercase letter
                              </div>
                              <div className={`text-xs ${validation.hasNumbers ? "text-green-400" : "text-red-400"}`}>
                                ✓ One number
                              </div>
                              <div
                                className={`text-xs ${validation.hasSpecialChar ? "text-green-400" : "text-red-400"}`}
                              >
                                ✓ One special character
                              </div>
                            </>
                          )
                        })()}
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <Label htmlFor="confirmPassword" className="text-gray-300">
                    Confirm Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      required
                      className="pl-10 bg-gray-800 border-gray-600 text-white"
                      value={formData.confirmPassword}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-orange-500 hover:bg-orange-600 text-white font-semibold py-3"
                >
                  Create Account
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>

                <div className="text-center">
                  <p className="text-sm text-gray-400">
                    Already have an account?{" "}
                    <Link href="/auth/login" className="text-orange-400 hover:text-orange-300">
                      Sign in
                    </Link>
                  </p>
                </div>
              </form>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
