"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  User,
  Calendar,
  BookOpen,
  Award,
  QrCode,
  Bell,
  Settings,
  LogOut,
  TrendingUp,
  Clock,
  Target,
} from "lucide-react"

export default function StudentDashboard() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="bg-gray-900 border-b border-gray-700 p-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Welcome back, John!</h1>
              <p className="text-gray-400 text-sm">Computer Science Student</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm">
              <Bell className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Settings className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <div className="p-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Stats Cards */}
            <div className="grid md:grid-cols-3 gap-4">
              <Card className="bg-gray-900 border-gray-700">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">GPA</p>
                      <p className="text-2xl font-bold text-green-400">3.85</p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-green-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-gray-700">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Attendance</p>
                      <p className="text-2xl font-bold text-blue-400">94%</p>
                    </div>
                    <Calendar className="w-8 h-8 text-blue-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-gray-700">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Credits</p>
                      <p className="text-2xl font-bold text-orange-400">18/20</p>
                    </div>
                    <BookOpen className="w-8 h-8 text-orange-400" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Current Courses */}
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Current Courses</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "Advanced Algorithms", code: "CS 401", progress: 75, grade: "A-" },
                    { name: "Database Systems", code: "CS 350", progress: 60, grade: "B+" },
                    { name: "Software Engineering", code: "CS 320", progress: 85, grade: "A" },
                    { name: "Machine Learning", code: "CS 480", progress: 45, grade: "B" },
                  ].map((course, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-800 rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold text-white">{course.name}</h3>
                          <Badge className="bg-green-500/20 text-green-400">{course.grade}</Badge>
                        </div>
                        <p className="text-gray-400 text-sm mb-2">{course.code}</p>
                        <div className="flex items-center space-x-2">
                          <Progress value={course.progress} className="flex-1" />
                          <span className="text-sm text-gray-400">{course.progress}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { action: "Assignment submitted", course: "CS 401", time: "2 hours ago", icon: Target },
                    { action: "Attended lecture", course: "CS 350", time: "1 day ago", icon: Clock },
                    { action: "Quiz completed", course: "CS 320", time: "2 days ago", icon: Award },
                    { action: "Project milestone", course: "CS 480", time: "3 days ago", icon: BookOpen },
                  ].map((activity, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-gray-800 rounded-lg">
                      <activity.icon className="w-5 h-5 text-orange-400" />
                      <div className="flex-1">
                        <p className="text-white text-sm">{activity.action}</p>
                        <p className="text-gray-400 text-xs">
                          {activity.course} • {activity.time}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* NFC Profile Card */}
            <Card className="bg-gradient-to-br from-orange-500/20 to-red-500/20 border-orange-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <QrCode className="w-5 h-5" />
                  <span>Your NFC Profile</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="w-32 h-32 mx-auto mb-4 bg-white rounded-lg flex items-center justify-center">
                  <QrCode className="w-16 h-16 text-black" />
                </div>
                <p className="text-gray-300 text-sm mb-4">
                  Tap your NFC card or scan this QR code to share your profile
                </p>
                <Button className="w-full bg-orange-500 hover:bg-orange-600">View Full Profile</Button>
              </CardContent>
            </Card>

            {/* Upcoming Events */}
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Upcoming</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { title: "CS 401 Midterm", date: "Tomorrow", time: "2:00 PM" },
                    { title: "Project Presentation", date: "Friday", time: "10:00 AM" },
                    { title: "Study Group", date: "Saturday", time: "3:00 PM" },
                  ].map((event, index) => (
                    <div key={index} className="p-3 bg-gray-800 rounded-lg">
                      <h4 className="font-semibold text-white text-sm">{event.title}</h4>
                      <p className="text-gray-400 text-xs">
                        {event.date} at {event.time}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300">
                  <BookOpen className="w-4 h-4 mr-2" />
                  View Grades
                </Button>
                <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300">
                  <Calendar className="w-4 h-4 mr-2" />
                  Check Schedule
                </Button>
                <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300">
                  <Award className="w-4 h-4 mr-2" />
                  View Certificates
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
