import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Smartphone, Brain, Users, BarChart3, Shield, Zap, ArrowRight, Star } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="fixed top-0 w-full z-50 bg-black/80 backdrop-blur-md border-b border-gray-800">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">EduNFC</span>
          </div>
          <nav className="hidden md:flex space-x-6">
            <a href="#features" className="hover:text-orange-400 transition-colors">
              Features
            </a>
            <a href="#how-it-works" className="hover:text-orange-400 transition-colors">
              How It Works
            </a>
            <a href="#pricing" className="hover:text-orange-400 transition-colors">
              Pricing
            </a>
          </nav>
          <Link href="/auth/login">
            <Button
              variant="outline"
              className="border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white"
            >
              Login
            </Button>
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        <div className="hero-gradient absolute inset-0"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[80vh]">
            <div className="space-y-8">
              <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30">
                🚀 Revolutionary Education Technology
              </Badge>
              <h1 className="text-5xl lg:text-7xl font-black leading-tight">
                Smart <span className="text-orange-500">NFC</span> Profiles for
                <span className="bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent">
                  {" "}
                  Modern Education
                </span>
              </h1>
              <p className="text-xl text-gray-300 leading-relaxed">
                Transform your educational experience with AI-powered NFC technology. Instant access to student
                profiles, grades, attendance, and intelligent insights.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/auth/register">
                  <Button
                    size="lg"
                    className="bg-orange-500 hover:bg-orange-600 text-white font-semibold px-8 py-4 text-lg"
                  >
                    Get Started Free
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </Link>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-gray-600 text-gray-300 hover:bg-gray-800 px-8 py-4 text-lg"
                >
                  Watch Demo
                </Button>
              </div>
              <div className="flex items-center space-x-6 text-sm text-gray-400">
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 text-yellow-400 fill-current" />
                  <span>4.9/5 Rating</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Users className="w-4 h-4" />
                  <span>10K+ Students</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Shield className="w-4 h-4 text-green-400" />
                  <span>100% Secure</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="gradient-bg absolute inset-0 rounded-3xl blur-3xl"></div>
              <div className="relative bg-gray-900/50 backdrop-blur-sm rounded-3xl p-8 border border-gray-700">
                <Image
                  src="/placeholder.svg?height=400&width=500"
                  alt="NFC Education Dashboard"
                  width={500}
                  height={400}
                  className="rounded-2xl"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 gradient-bg">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30 mb-4">⚡ Powerful Features</Badge>
            <h2 className="text-4xl lg:text-5xl font-bold mb-6">
              Everything You Need for <span className="text-orange-500">Smart Education</span>
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Our NFC-powered platform combines cutting-edge technology with intuitive design to revolutionize how
              students and teachers interact.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Smartphone,
                title: "NFC Smart Profiles",
                description:
                  "Instant access to student information with a simple tap. No apps, no passwords, just seamless interaction.",
                color: "text-orange-500",
              },
              {
                icon: Brain,
                title: "AI-Powered Insights",
                description:
                  "Get intelligent recommendations and insights about student performance and learning patterns.",
                color: "text-green-500",
              },
              {
                icon: BarChart3,
                title: "Real-time Analytics",
                description: "Track attendance, grades, and progress with beautiful, actionable dashboards.",
                color: "text-blue-500",
              },
              {
                icon: Shield,
                title: "Secure & Private",
                description:
                  "Bank-level security ensures all student data is protected and compliant with privacy regulations.",
                color: "text-purple-500",
              },
              {
                icon: Users,
                title: "Role-Based Access",
                description:
                  "Customized experiences for students, teachers, and administrators with appropriate permissions.",
                color: "text-red-500",
              },
              {
                icon: Zap,
                title: "Lightning Fast",
                description: "Sub-second response times ensure smooth, uninterrupted educational workflows.",
                color: "text-yellow-500",
              },
            ].map((feature, index) => (
              <Card
                key={index}
                className="bg-gray-900/50 border-gray-700 hover:border-orange-500/50 transition-all duration-300 hover:transform hover:scale-105"
              >
                <CardContent className="p-6">
                  <feature.icon className={`w-12 h-12 ${feature.color} mb-4`} />
                  <h3 className="text-xl font-semibold mb-3 text-white">{feature.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20 bg-gray-900/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30 mb-4">📋 Simple Process</Badge>
            <h2 className="text-4xl lg:text-5xl font-bold mb-6">
              How <span className="text-orange-500">EduNFC</span> Works
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Get started in minutes with our streamlined 4-step process
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Register & Choose Role",
                description: "Sign up and select whether you're a student or teacher",
                icon: Users,
              },
              {
                step: "02",
                title: "Create Your Profile",
                description: "Add your information, courses, and preferences",
                icon: Brain,
              },
              {
                step: "03",
                title: "Get Your NFC Card",
                description: "Receive your personalized NFC-enabled student/teacher card",
                icon: Smartphone,
              },
              {
                step: "04",
                title: "Start Learning",
                description: "Tap to access profiles, track attendance, and collaborate",
                icon: Zap,
              },
            ].map((step, index) => (
              <div key={index} className="text-center relative">
                <div className="bg-gradient-to-r from-orange-500 to-red-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-white font-bold text-lg">{step.step}</span>
                </div>
                <step.icon className="w-8 h-8 text-orange-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3 text-white">{step.title}</h3>
                <p className="text-gray-400">{step.description}</p>
                {index < 3 && <ArrowRight className="hidden lg:block absolute top-8 -right-4 w-6 h-6 text-gray-600" />}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl lg:text-5xl font-bold mb-6">
            Ready to Transform Your <span className="text-orange-500">Educational Experience</span>?
          </h2>
          <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
            Join thousands of students and teachers already using EduNFC to streamline their educational journey.
          </p>
          <Link href="/auth/register">
            <Button size="lg" className="bg-orange-500 hover:bg-orange-600 text-white font-semibold px-12 py-4 text-xl">
              Register Now - It's Free!
              <ArrowRight className="ml-2 w-6 h-6" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black border-t border-gray-800 py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
                  <Smartphone className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">EduNFC</span>
              </div>
              <p className="text-gray-400">Revolutionizing education through smart NFC technology.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-orange-400">
                    Features
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-orange-400">
                    Pricing
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-orange-400">
                    Security
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-orange-400">
                    Documentation
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-orange-400">
                    Help Center
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-orange-400">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-orange-400">
                    About
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-orange-400">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-orange-400">
                    Careers
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 EduNFC. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
