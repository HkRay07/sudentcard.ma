"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Smartphone, Scan, CheckCircle, XCircle } from "lucide-react"

interface NFCScannerProps {
  onScanSuccess?: (nfcId: string) => void
  onScanError?: (error: string) => void
}

export function NFCScanner({ onScanSuccess, onScanError }: NFCScannerProps) {
  const [isScanning, setIsScanning] = useState(false)
  const [scanResult, setScanResult] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const simulateNFCScan = async () => {
    setIsScanning(true)
    setError(null)
    setScanResult(null)

    try {
      // Simulate NFC scanning delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Simulate successful scan with mock NFC ID
      const mockNfcId = `NFC${Math.floor(Math.random() * 1000)
        .toString()
        .padStart(3, "0")}`
      setScanResult(mockNfcId)
      onScanSuccess?.(mockNfcId)
    } catch (err) {
      const errorMessage = "Failed to scan NFC device"
      setError(errorMessage)
      onScanError?.(errorMessage)
    } finally {
      setIsScanning(false)
    }
  }

  return (
    <Card className="bg-gray-900 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center space-x-2">
          <Smartphone className="w-5 h-5" />
          <span>NFC Scanner</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="text-center space-y-4">
        <div className="w-24 h-24 mx-auto bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center">
          {isScanning ? (
            <div className="animate-spin">
              <Scan className="w-12 h-12 text-white" />
            </div>
          ) : (
            <Smartphone className="w-12 h-12 text-white" />
          )}
        </div>

        {scanResult && (
          <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span className="text-green-400 font-semibold">Scan Successful</span>
            </div>
            <Badge className="bg-green-500/20 text-green-400">ID: {scanResult}</Badge>
          </div>
        )}

        {error && (
          <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
            <div className="flex items-center justify-center space-x-2">
              <XCircle className="w-5 h-5 text-red-400" />
              <span className="text-red-400 text-sm">{error}</span>
            </div>
          </div>
        )}

        <Button
          onClick={simulateNFCScan}
          disabled={isScanning}
          className="w-full bg-orange-500 hover:bg-orange-600 disabled:opacity-50"
        >
          {isScanning ? "Scanning..." : "Scan NFC Device"}
        </Button>

        <p className="text-gray-400 text-sm">Hold your NFC-enabled device near the scanner</p>
      </CardContent>
    </Card>
  )
}
