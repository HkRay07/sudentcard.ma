-- Insert sample users
INSERT INTO users (email, password_hash, role, first_name, last_name, institution, massar_code) VALUES
('john.doe@university.edu', '$2b$10$example_hash_1', 'student', 'John', 'Doe', 'Tech University', 'A123456789'),
('jane.smith@university.edu', '$2b$10$example_hash_2', 'student', 'Jane', 'Smith', 'Tech University', 'B987654321'),
('prof.wilson@university.edu', '$2b$10$example_hash_3', 'teacher', 'Robert', 'Wilson', 'Tech University', 'T111222333'),
('prof.davis@university.edu', '$2b$10$example_hash_4', 'teacher', 'Sarah', 'Davis', 'Tech University', 'T444555666');

-- Insert sample courses
INSERT INTO courses (code, name, description, teacher_id, semester, year) VALUES
('CS401', 'Advanced Algorithms', 'Advanced algorithmic techniques and analysis', 3, 'Fall', 2024),
('CS350', 'Database Systems', 'Database design and implementation', 3, 'Fall', 2024),
('CS320', 'Software Engineering', 'Software development methodologies', 4, 'Fall', 2024),
('CS480', 'Machine Learning', 'Introduction to machine learning concepts', 4, 'Fall', 2024);

-- Insert sample profiles
INSERT INTO profiles (user_id, bio, nfc_id, grades, attendance, courses) VALUES
(1, 'Computer Science student passionate about algorithms', 'NFC001', 
 '{"CS401": "A-", "CS350": "B+", "CS320": "A", "CS480": "B"}',
 '{"overall": 94, "CS401": 92, "CS350": 85, "CS320": 98, "CS480": 90}',
 '["CS401", "CS350", "CS320", "CS480"]'),
(2, 'Aspiring software engineer with focus on web development', 'NFC002',
 '{"CS401": "B+", "CS350": "A-", "CS320": "A", "CS480": "B+"}',
 '{"overall": 96, "CS401": 95, "CS350": 92, "CS320": 100, "CS480": 88}',
 '["CS401", "CS350", "CS320", "CS480"]');

-- Insert sample enrollments
INSERT INTO enrollments (student_id, course_id, grade, attendance_percentage) VALUES
(1, 1, 'A-', 92.0),
(1, 2, 'B+', 85.0),
(1, 3, 'A', 98.0),
(1, 4, 'B', 90.0),
(2, 1, 'B+', 95.0),
(2, 2, 'A-', 92.0),
(2, 3, 'A', 100.0),
(2, 4, 'B+', 88.0);
